module ApplicationHelper
  def somar_dois(val)
    val + 2
  end
end
