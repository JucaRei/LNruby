# Ruby on Rails - Curso Completo

Aqui ficarão os execícios do curso de Ruby on Rails Completo da Udemy

Deseja adquirir o curso? Acesse o link abaixo e saiba como.

>> [Ruby on Rails - Curso Completo](http://jacksonpires.blogspot.com.br/2016/05/novo-curso-de-rails-na-udemy.html)
