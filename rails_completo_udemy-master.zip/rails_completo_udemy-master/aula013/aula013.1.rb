x = ARGV
puts x.inspect
puts x