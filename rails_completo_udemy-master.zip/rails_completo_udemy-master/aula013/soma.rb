x = ARGV[0].to_i + ARGV[1].to_i
puts x