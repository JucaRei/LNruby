v = [15,24,34,84]
puts v.class
puts v.inspect
puts v
puts v[2]

a = Array.new
a.push(4)
puts a.inspect