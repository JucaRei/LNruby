ror = "Ruby on Rails"
ROR = "Ruby on Rails"

puts ror
puts ROR

ROR = "Ruby"

puts ROR