def soma(a, b)
  puts "O resultado é: #{a + b}"
end

soma(4,5)

soma 8, 7