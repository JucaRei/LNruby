(1..10).each do |i|
  puts i
end

puts "==========="

(1...10).each do |i|
  puts i
end
  