require_relative "venda"

v = Venda.new
v.vender