module KindsHelper
end
