class Contact < ActiveRecord::Base
  belongs_to :kind
end
