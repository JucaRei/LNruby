class Address < ActiveRecord::Base
  belongs_to :contact
end
