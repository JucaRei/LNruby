class Kind < ActiveRecord::Base
end
