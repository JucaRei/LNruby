class Pessoa
  attr_accessor :nome
  attr_accessor :endereco
end